# pyisotopomer: Nitrous oxide isotopocule data corrections in Python
# Copyright (C) 2021  Colette L Kelly et al.  (MIT License)

from .pyisotopomer import Scrambling
from .pyisotopomer import Isotopomers